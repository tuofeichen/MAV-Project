// int counter = 0;
//
// take off to first hight h1
//
// find a wall (90degree from drone to wall)
// go towards wall until distance d1
// turn 90degrees to right
// go towards wall until distance d1
// turn 90degrees to right
// go towards wall until distance d1
// turn 90degrees to right
// go towards wall until distance d1
// turn 90degrees to right
// go towards wall until distance d1
// turn 90degrees to right
// go towards wall until distance d1
// turn 90degrees


// for(int j = 0; j < Number of h); j++)
//{
//
// 		for(int i = 0;i< Numbers of d; i++)
//		{
// 			go towards wall until distance d(i)
// 			turn 90degrees
// 			go towards wall until distance d(i)
//		    turn 90degrees
// 			go towards wall until distance d(i)
// 			turn 90degrees
// 			go towards wall until distance d(i)
// 			turn 90 degrees
// 		}
// 
// 	go to height h(j)
// }
//
//
//
//void CameraCallBack(){
//	if(valid position) counter ++;
//
//  if(counter > 30) land();
//}
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

