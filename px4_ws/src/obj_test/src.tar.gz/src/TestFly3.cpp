 #include <sensor_msgs/Imu.h>
#include <geometry_msgs/Point.h>
#include "ros/ros.h"
#include <iostream>
#include <string.h>
#include "geometry_msgs/TwistStamped.h"
#include "geometry_msgs/Vector3Stamped.h"
#include "geometry_msgs/PoseStamped.h"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/features2d.hpp"
#include "opencv2/calib3d/calib3d.hpp"
#include "Frame.h"
#include "AsusProLiveOpenNI2.h"
#include "obj_test/JoyCommand.h"

////////////////////////////////////////
// test 3
//
// takes off
// spin arround
// 
// if perpendicular wall is seen, hover
//
// end
//////////////////////////////////////

obj_test::JoyCommand MovePosition;
bool take_off_done=false;
bool not_found = true;
double depth_right_most_pixel=-1;
double depth_central_pixel=-1;


void velCallback(const geometry_msgs::TwistStamped vel);
void spCallback(const geometry_msgs::PoseStamped sp);
void wallCallback(const geometry_msgs::Point pixel_depth);
bool CheckForWall();


int main(int argc, char **argv) 
{
	ros::init(argc, argv, "ObjectFind");
	ros::NodeHandle nh;
	ros::Rate loop_rate(5);
	
	ros::Publisher move_pub = nh.advertise<obj_test::JoyCommand>("/april/cmd_mav", 100); // publish how much the drone should move
	ros::Subscriber sp_sub = nh.subscribe("/mavros/setpoint_position/local", 100, &spCallback);
	ros::Subscriber vel_sub = nh.subscribe("/mavros/setpoint_velocity/cmd_vel", 100, &velCallback);	
	ros::Subscriber wall_sub = nh.subscribe("/PerpendicularWallFind", 100, &wallCallback);	
	
	while(ros::ok())
	{
		
		if(take_off_done)
		{
			if(!CheckForWall()){
			 ROS_INFO("Spinning!");
			 MovePosition.position.x = 0;
             MovePosition.position.y = 0;
             MovePosition.position.z = 0;
             MovePosition.yaw = 1;
			 move_pub.publish(MovePosition);
			}
			else
			{
			 ROS_INFO("Wall Found. Hovering now.");
			 MovePosition.position.x = 0;
             MovePosition.position.y = 0;
             MovePosition.position.z = 0;
             MovePosition.yaw = 0;
			 move_pub.publish(MovePosition);
			 return 0;
			}
			

		}
		
	ros::spinOnce();
	loop_rate.sleep();	
	}

	return 0;
}


void velCallback(const geometry_msgs::TwistStamped vel) // when it is in velocity control the take off is not complete yet
{
  take_off_done = false;
}

void spCallback(const geometry_msgs::PoseStamped sp)    // when it is in position control the take off is finished
{	
  take_off_done = true;
}

void wallCallback(const geometry_msgs::Point pixel_depth)    // when it is in position control the take off is finished
{	
  depth_central_pixel = pixel_depth.x ;
  depth_right_most_pixel = pixel_depth.y ;
}

bool CheckForWall()
{
	// 58 is the AOV
	
	//ROS_INFO("depth_central_pixel: %f",depth_central_pixel);
	ROS_INFO("%f,%f,%f,%f,%f", depth_right_most_pixel, cos(((58./2)/180.)*3.14) , depth_central_pixel,depth_right_most_pixel*cos(((58./2)/180.)*3.14) ,fabs(depth_right_most_pixel*cos(((58./2)/180.)*3.14)  - depth_central_pixel) );
	
	if(depth_central_pixel > 0 && depth_right_most_pixel > 0 && depth_right_most_pixel < 3500 && depth_central_pixel < 3500){
		
		if(fabs(depth_right_most_pixel*cos(((58./2)/180.)*3.14) - depth_central_pixel) < 10 )
		{
			ROS_INFO("hi");
			return true;
		}
	}
	
	return false;
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	