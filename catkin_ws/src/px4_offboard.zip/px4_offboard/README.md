This is a EECS 399 Project with Prof Kataseggelos on Visual SLAM implementation on a Pixhawk.
